package in.ineuron;
import java.util.*;
/**
 * @author Surbhi
 *
 */
public class SquareRoot {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Scanner sc =new Scanner(System.in);
		int x=sc.nextInt();
		for(int i=1;i<=x/2;i++) {
			if(i*i ==x) {
				System.out.println(i);
				break;
			}
			else if(i*i>x) {
				System.out.println(i-1);
				break;
			}
		}

	}

}
